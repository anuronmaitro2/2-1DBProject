//get patientID from url params
 const urlParams = new URLSearchParams(window.location.search);
    const patientId = urlParams.get("patientId");
    console.log(patientId);

    //show all prescriptions
    const showAllPrescriptions= async () => {
      //call 4 functions here
      getAllGivenMedicine();
      getAllGivenAdvice();
      getAllGivenTests();
        getAllGivenTestResults();
    }
    
   //1 
   const getAllGivenMedicine = async () => {
    const options = {
      method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            patientId: patientId,
        }),
    };
    const url = "http://localhost:3000/prescription/getAllGivenMedicine";
    const response = await fetch(url, options);
    const givenMedicine = await response.json();
    console.log(givenMedicine);
    //displayGiven medicine in a table
    displayGivenMedicine(givenMedicine);
}
//display given medicine in a table
const displayGivenMedicine = (givenMedicine) => {
    const givenMedicineDiv = document.getElementById("givenMedicine");
    givenMedicineDiv.innerHTML = "";
    const table = document.createElement("table");
    // Add table header row
    const headerRow = document.createElement("tr");
    for(let key in givenMedicine[0]){
        const th = document.createElement("th");
        th.textContent = key;
        headerRow.appendChild(th);
    }
    table.appendChild(headerRow);
    // Add table rows
    for(let medicine of givenMedicine){
        const row = document.createElement("tr");
        for(let key in medicine){
            const cell = document.createElement("td");
            cell.textContent = medicine[key];
            row.appendChild(cell);
        }
        table.appendChild(row);
    }
    //create a header with content All Given Medicine
    const header = document.createElement("h2");
    header.textContent = "All Given Medicine";
    givenMedicineDiv.appendChild(header);

    givenMedicineDiv.appendChild(table);
}
//2
//get all given advice
const getAllGivenAdvice = async () => {
    const options = {
      method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            patientId: patientId,
        }),
    };
    const url = "http://localhost:3000/prescription/getAllGivenAdvice";
    const response = await fetch(url, options);
    const givenAdvice = await response.json();
    console.log(givenAdvice);
    //displayGivenAdvice in a table
    displayGivenAdvice(givenAdvice);
}
//display given advice in a table
const displayGivenAdvice = (givenAdvice) => {
    const givenAdviceDiv = document.getElementById("givenAdvice");
    givenAdviceDiv.innerHTML = "";
    const table = document.createElement("table");
    // Add table header row
    const headerRow = document.createElement("tr");
    for(let key in givenAdvice[0]){
        const th = document.createElement("th");
        th.textContent = key;
        headerRow.appendChild(th);
    }
    table.appendChild(headerRow);
    // Add table rows
    for(let advice of givenAdvice){
        const row = document.createElement("tr");
        for(let key in advice){
            const cell = document.createElement("td");
            cell.textContent = advice[key];
            row.appendChild(cell);
        }
        table.appendChild(row);
    }
    //create a header with content All Given Advice
    const header = document.createElement("h2");
    header.textContent = "All Given Advice";
    givenAdviceDiv.appendChild(header);

    givenAdviceDiv.appendChild(table);
}

//3
//get all given tests
const getAllGivenTests = async () => {
    const options = {
      method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            patientId: patientId,
        }),
    };
    const url = "http://localhost:3000/prescription/getAllGivenTests";
    const response = await fetch(url, options);
    const givenTests = await response.json();
    console.log(givenTests);
    //displayGivenTests in a table
    displayGivenTests(givenTests);
}
//display given tests in a table
const displayGivenTests = (givenTests) => {
    const givenTestsDiv = document.getElementById("givenTests");
    givenTestsDiv.innerHTML = "";
    const table = document.createElement("table");
    // Add table header row
    const headerRow = document.createElement("tr");
    for(let key in givenTests[0]){
        const th = document.createElement("th");
        th.textContent = key;
        headerRow.appendChild(th);
    }
    table.appendChild(headerRow);
    // Add table rows
    for(let test of givenTests){
        const row = document.createElement("tr");
        for(let key in test){
            const cell = document.createElement("td");
            cell.textContent = test[key];
            row.appendChild(cell);
        }
        table.appendChild(row);
    }
    //create a header with content All Given Tests
    const header = document.createElement("h2");
    header.textContent = "All Given Tests";
    givenTestsDiv.appendChild(header);

    givenTestsDiv.appendChild(table);
}
//4
//get result of all given tests
const getAllGivenTestResults = async () => {
    const options = {
      method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            patientId: patientId,
        }),
    };
    const url = "http://localhost:3000/prescription/getAllGivenTestResults";
    const response = await fetch(url, options);
    const givenTestResults = await response.json();
    console.log(givenTestResults);
    //displayGivenTestResults in a table
    displayGivenTestResults(givenTestResults);
}
//display given test results in a table
const displayGivenTestResults = (givenTestResults) => {
    const givenTestResultsDiv = document.getElementById("givenTestResults");
    givenTestResultsDiv.innerHTML = "";
    const table = document.createElement("table");
    // Add table header row
    const headerRow = document.createElement("tr");
    for(let key in givenTestResults[0]){
        const th = document.createElement("th");
        th.textContent = key;
        headerRow.appendChild(th);
    }
    table.appendChild(headerRow);
    // Add table rows
    for(let testResult of givenTestResults){
        const row = document.createElement("tr");
        for(let key in testResult){
            const cell = document.createElement("td");
            cell.textContent = testResult[key];
            row.appendChild(cell);
        }
        table.appendChild(row);
    }
    //create a header with content All Given Test Results
    const header = document.createElement("h2");
    header.textContent = "All Given Test Results";
    givenTestResultsDiv.appendChild(header);

    givenTestResultsDiv.appendChild(table);
}

//APPOINTMENT specific type 
const showPrescriptionOnaGivenAppointment= async () => {
    //call 4 functions here
    getAllGivenMedicineOnaGivenAppointment();
    getAllGivenAdviceOnaGivenAppointment();
    getAllGivenTestsOnaGivenAppointment();
    getAllGivenTestResultsOnaGivenAppointment();
}

//1
//get all given medicine on a given appointment
const getAllGivenMedicineOnaGivenAppointment = async () => {
    //get appointmentId from input
    const appointmentId = document.getElementById("appointmentIDForPrescription").value;
    const options = {
      method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            patientId: patientId,
            appointmentId: appointmentId,
        }),
    };
    const url = "http://localhost:3000/prescription/getAllGivenMedicineOnaGivenAppointment";
    const response = await fetch(url, options);
    const givenMedicineOnaGivenAppointment = await response.json();
    console.log(givenMedicineOnaGivenAppointment);
    //displayGiven medicine in a table
    displayGivenMedicineOnaGivenAppointment(givenMedicineOnaGivenAppointment);
}
//display given medicine in a table
const displayGivenMedicineOnaGivenAppointment = (givenMedicineOnaGivenAppointment) => {
    const givenMedicineOnaGivenAppointmentDiv = document.getElementById("givenMedicineOnaGivenAppointment");
    givenMedicineOnaGivenAppointmentDiv.innerHTML = "";
    const table = document.createElement("table");
    // Add table header row
    const headerRow = document.createElement("tr");
    for(let key in givenMedicineOnaGivenAppointment[0]){
        const th = document.createElement("th");
        th.textContent = key;
        headerRow.appendChild(th);
    }
    table.appendChild(headerRow);
    // Add table rows
    for(let medicine of givenMedicineOnaGivenAppointment){
        const row = document.createElement("tr");
        for(let key in medicine){
            const cell = document.createElement("td");
            cell.textContent = medicine[key];
            row.appendChild(cell);
        }
        table.appendChild(row);
    }
    //create a header with content All Given Medicine
    const header = document.createElement("h2");
    header.textContent = "All Given Medicine On a Given Appointment";
    givenMedicineOnaGivenAppointmentDiv.appendChild(header);

    givenMedicineOnaGivenAppointmentDiv.appendChild(table);
}

//2
//get all given advice on a given appointment
const getAllGivenAdviceOnaGivenAppointment = async () => {
    //get appointmentId from input
    const appointmentId = document.getElementById("appointmentIDForPrescription").value;
    const options = {
      method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            patientId: patientId,
            appointmentId: appointmentId,
        }),
    };
    const url = "http://localhost:3000/prescription/getAllGivenAdviceOnaGivenAppointment";
    const response = await fetch(url, options);
    const givenAdviceOnaGivenAppointment = await response.json();
    console.log(givenAdviceOnaGivenAppointment);
    //displayGivenAdvice in a table
    displayGivenAdviceOnaGivenAppointment(givenAdviceOnaGivenAppointment);
}
//display given advice in a table
const displayGivenAdviceOnaGivenAppointment = (givenAdviceOnaGivenAppointment) => {
    const givenAdviceOnaGivenAppointmentDiv = document.getElementById("givenAdviceOnaGivenAppointment");
    givenAdviceOnaGivenAppointmentDiv.innerHTML = "";
    const table = document.createElement("table");
    // Add table header row
    const headerRow = document.createElement("tr");
    for(let key in givenAdviceOnaGivenAppointment[0]){
        const th = document.createElement("th");
        th.textContent = key;
        headerRow.appendChild(th);
    }
    table.appendChild(headerRow);
    // Add table rows
    for(let advice of givenAdviceOnaGivenAppointment){
        const row = document.createElement("tr");
        for(let key in advice){
            const cell = document.createElement("td");
            cell.textContent = advice[key];
            row.appendChild(cell);
        }
        table.appendChild(row);
    }
    //create a header with content All Given Advice
    const header = document.createElement("h2");
    header.textContent = "All Given Advice On a Given Appointment";
    givenAdviceOnaGivenAppointmentDiv.appendChild(header);

    givenAdviceOnaGivenAppointmentDiv.appendChild(table);
}

//3
//get all given tests on a given appointment
const getAllGivenTestsOnaGivenAppointment = async () => {
    //get appointmentId from input
    const appointmentId = document.getElementById("appointmentIDForPrescription").value;
    const options = {
      method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            patientId: patientId,
            appointmentId: appointmentId,
        }),
    };
    const url = "http://localhost:3000/prescription/getAllGivenTestsOnaGivenAppointment";
    const response = await fetch(url, options);
    const givenTestsOnaGivenAppointment = await response.json();
    console.log(givenTestsOnaGivenAppointment);
    //displayGivenTests in a table
    displayGivenTestsOnaGivenAppointment(givenTestsOnaGivenAppointment);
}
//display given tests in a table
const displayGivenTestsOnaGivenAppointment = (givenTestsOnaGivenAppointment) => {
    const givenTestsOnaGivenAppointmentDiv = document.getElementById("givenTestsOnaGivenAppointment");
    givenTestsOnaGivenAppointmentDiv.innerHTML = "";
    const table = document.createElement("table");
    // Add table header row
    const headerRow = document.createElement("tr");
    for(let key in givenTestsOnaGivenAppointment[0]){
        const th = document.createElement("th");
        th.textContent = key;
        headerRow.appendChild(th);
    }
    table.appendChild(headerRow);
    // Add table rows
    for(let test of givenTestsOnaGivenAppointment){
        const row = document.createElement("tr");
        for(let key in test){
            const cell = document.createElement("td");
            cell.textContent = test[key];
            row.appendChild(cell);
        }
        table.appendChild(row);
    }
    //create a header with content All Given Tests
    const header = document.createElement("h2");
    header.textContent = "All Given Tests On a Given Appointment";
    givenTestsOnaGivenAppointmentDiv.appendChild(header);

    givenTestsOnaGivenAppointmentDiv.appendChild(table);
}
//4
//get result of all given tests on a given appointment
const getAllGivenTestResultsOnaGivenAppointment = async () => {
    //get appointmentId from input
    const appointmentId = document.getElementById("appointmentIDForPrescription").value;
    const options = {
      method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            patientId: patientId,
            appointmentId: appointmentId,
        }),
    };
    const url = "http://localhost:3000/prescription/getAllGivenTestResultsOnaGivenAppointment";
    const response = await fetch(url, options);
    const givenTestResultsOnaGivenAppointment = await response.json();
    console.log(givenTestResultsOnaGivenAppointment);
    //displayGivenTestResults in a table
    displayGivenTestResultsOnaGivenAppointment(givenTestResultsOnaGivenAppointment);
}
//display given test results in a table
const displayGivenTestResultsOnaGivenAppointment = (givenTestResultsOnaGivenAppointment) => {
    const givenTestResultsOnaGivenAppointmentDiv = document.getElementById("givenTestResultsOnaGivenAppointment");
    givenTestResultsOnaGivenAppointmentDiv.innerHTML = "";
    const table = document.createElement("table");
    // Add table header row
    const headerRow = document.createElement("tr");
    for(let key in givenTestResultsOnaGivenAppointment[0]){
        const th = document.createElement("th");
        th.textContent = key;
        headerRow.appendChild(th);
    }
    table.appendChild(headerRow);
    // Add table rows
    for(let testResult of givenTestResultsOnaGivenAppointment){
        const row = document.createElement("tr");
        for(let key in testResult){
            const cell = document.createElement("td");
            cell.textContent = testResult[key];
            row.appendChild(cell);
        }
        table.appendChild(row);
    }
    //create a header with content All Given Test Results
    const header = document.createElement("h2");
    header.textContent = "All Given Test Results On a Given Appointment";
    givenTestResultsOnaGivenAppointmentDiv.appendChild(header);

    givenTestResultsOnaGivenAppointmentDiv.appendChild(table);
}