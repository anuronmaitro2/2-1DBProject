const morgan = require('morgan');
const express = require('express');
const router = require('express-promise-router')();
const oracleDb = require('oracledb');
oracleDb.outFormat = oracleDb.OUT_FORMAT_OBJECT;
const cors = require('cors');

//create connection pool with oracle database
let connection = undefined;
async function db_query(query, params) {
    if (connection === undefined) {
        connection = await oracleDb.getConnection({
            user: "maitro",
            password: "123",
            connectString: "localhost:1521/ORCL"
        });
    }
    try {

        let result = await connection.execute(query, params, { autoCommit: true });
        return result.rows;
    }
    catch (err) {
        console.log(err);
        return undefined;
    }
}
const app = express();
app.use(cors());
app.options('*', cors());//enable pre-flight
app.use(express.json());
app.use(morgan('dev'));
app.use(router);


//register as a patient

router.post('/registerAsAPatient', async (req, res) => {
    const { firstName, lastName, dob, gender, contactNo, disease, address } = req.body;
    console.log(req.body);

    try {
        const query = "INSERT INTO PATIENT (PATIENT_ID, FIRSTNAME, LASTNAME, DOB, GENDER, CONTACT_NO, DISEASE, ADDRESS) " +
            "VALUES (PATIENT_SEQ.NEXTVAL, :firstName, :lastName, TO_DATE(:dob, 'YYYY-MM-DD'), :gender, :contactNo, :disease, :address)";
        const params = { firstName, lastName, dob, gender, contactNo, disease, address };


        await db_query(query, params);
        res.status(200).json({ message: 'Patient registered successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


//login as a patient
router.post('/loginAsAPatient/:patientId', async (req, res) => {
    const { id } = req.params;
    console.log(req.params);
    console.log(req.params.patientId);
    //convert into number
    const id1 = parseInt(req.params.patientId);
    console.log("converted id");
    console.log(id1);

    try {
        const query = "SELECT * FROM PATIENT WHERE PATIENT_ID = :id1";
        const params = { id1 };

        const result = await db_query(query, params);
        console.log(result);
        if (result.length === 0) {
            res.status(400).json({ error: 'Invalid Credentials' });
        } else {
            //send the result
            //send the patient table
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


//search a doctor
router.post('/searchDoctors', async (req, res) => {

    console.log(req.body);
    console.log(req.body.speciality);
    const speciality = req.body.speciality;

    try {
        const query = "SELECT D.DoctorId, D.FirstName, D.LastName, D.Contact_No, D.GENDER, D.EXPERIENCE, D.PAYMENT, DS.Speciality FROM DOCTOR D JOIN DOCTORSPECIALITY DS ON D.DoctorId = DS.DoctorId WHERE LOWER(DS.Speciality) LIKE :speciality";
        const params = { speciality: `%${speciality}%` };

        const result = await db_query(query, params);

        console.log(result);
        if (result.length === 0) {
            res.status(400).json({ error: 'Invalid Credentials' });
        } else {
            //send the result
            //send the patient table
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


//login as a doctor
router.post('/loginAsADoctor/:doctorId', async (req, res) => {
    const { id } = req.params;
    console.log(req.params);
    console.log(req.params.doctorId);
    //convert into number
    const id1 = parseInt(req.params.doctorId);
    console.log("converted id");
    console.log(id1);

    try {
        const query = "SELECT * FROM DOCTOR WHERE DOCTORID = :id1";
        const params = { id1 };

        const result = await db_query(query, params);
        console.log(result);
        if (result.length === 0) {
            res.status(400).json({ error: 'Invalid Credentials' });
        } else {
            //send the result
            //send the patient table
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//set appointment
// Set appointment endpoint
router.post('/setAppointment', async (req, res) => {
    const { patientId, doctorId, notes } = req.body;

    try {
        // Modify this query to include SYSDATE for the appointment date
        const query = `
        INSERT INTO APPOINTMENT (APPOINTMENTID,PATIENTID,DOCTORID,APPOINTMENTDATE,NOTES) VALUES (SEQ_APPOINTMENT_ID.NEXTVAL, :patientId, :doctorId, SYSDATE, :notes)`;

        const params = { patientId, doctorId, notes };

        // Execute the query
        await db_query(query, params);

        // Send a success response
        res.status(200).json({ message: 'Appointment set successfully!' });
    } catch (error) {
        console.error(error);
        // Send an error response
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


//view appointment as a doctor
router.get('/viewAppointments/:doctorId', async (req, res) => {
    const { doctorId } = req.params;

    try {
        const query = `SELECT * FROM APPOINTMENT WHERE DOCTORID =:doctorId AND NOTES='PENDING'`;


        const params = { doctorId };

        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(200).json(result);
        } else {
            // Send the result
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//approve appointment

// Approve appointment
router.put('/approveAppointment/:appointmentId', async (req, res) => {
    const { appointmentId } = req.params;

    try {
        const query = `
        UPDATE APPOINTMENT
        SET NOTES = 'APPROVED'
        WHERE APPOINTMENTID = :appointmentId`;

        const params = { appointmentId };

        await db_query(query, params);

        res.status(200).json({ message: 'Appointment approved successfully!' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});



//view prescription and patient details

router.get('/viewPatientDetails/:appointmentId', async (req, res) => {
    const { appointmentId } = req.params;

    try {
        const query = "SELECT P.FIRSTNAME, P.DISEASE, P.GENDER,A.APPOINTMENTID " +
            "FROM APPOINTMENT A JOIN PATIENT P ON A.PATIENTID = P.PATIENT_ID " +
            "WHERE A.APPOINTMENTID = :appointmentId";
        const params = { appointmentId };

        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(404).json({ error: 'Patient details not found for the given appointment ID' });
        } else {
            res.status(200).json(result[0]);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//insert prescription
//'/insertPrescription'
router.post('/insertPrescription', async (req, res) => {
    const { appointmentId, status } = req.body;

    try {
        const query = `
      INSERT INTO PRESCRIPTION(PRESCRIPTIONID,APPOINTMENTID,PRESCRIPTION_STATUS) VALUES (SEQ_PRESCRIPTION_ID.NEXTVAL, :appointmentId, :status)`;

        const params = { appointmentId, status };

        await db_query(query, params);

        res.status(200).json({ message: 'Patient details inserted into prescription table' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//showing all medicines
router.post('/viewMedicines', async (req, res) => {
    try {
        const query = "SELECT * FROM MEDICINES  wHERE LOWER(MEDICINENAME)LIKE :medicineName";
        const { medcineName } = req.body;
        const params = { medicineName: `%${medcineName}%` };
        console.log(params);

        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(404).json({ error: 'No medicines found' });
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//get priscription id of appointment id
router.get('/getPrescriptionID/:appointmentId', async (req, res) => {
    const { appointmentId } = req.params;

    try {
        const query = `SELECT PRESCRIPTIONID FROM PRESCRIPTION WHERE APPOINTMENTID=:appointmentId`;

        const params = { appointmentId };

        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(404).json({ error: 'Prescription ID not found for the given appointment ID' });
        } else {
            res.status(200).json(result[0]);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//adding medicine to prescription
router.post('/insertMedicineIntoPrescription', async (req, res) => {
    //const { prescriptionIdt, medicineIdt } = req.body;
    //convert into number
    const prescriptionId1 = parseInt(req.body.prescriptionId);
    const medicineId1 = parseInt(req.body.medicineId);
    let prescriptionId = prescriptionId1;
    let medicineId = medicineId1;
    console.log("converted id")

    try {
        //const query1 = `INSERT INTO PRESCRIBEDMEDICINE(PRESCRIBEDMEDICINEID,PRESCRIPTIONID) VALUES (SEQ_PRESCRIBEDMEDICINE_ID.NEXTVAL, :prescriptionId)`;
        const sequencequery = `SELECT SEQ_PRESCRIBEDMEDICINE_ID.NEXTVAL FROM DUAL`;
        const result1 = await db_query(sequencequery, {});
        const prescribedmedicineid = result1[0].NEXTVAL;
        console.log(prescribedmedicineid);
        const query1 = `INSERT INTO PRESCRIBEDMEDICINE(PRESCRIBEDMEDICINEID,PRESCRIPTIONID) VALUES (:prescribedmedicineid,:prescriptionId)`;
        const params1 = { prescribedmedicineid, prescriptionId };
        const result2 = await db_query(query1, params1);
        console.log(result2);
        console.log("prescribedmedicineid inserted into prescribedmedicine table");
        const query2 = `INSERT INTO ALLMEDICINEPRESCRIBERMEDICINERELATION(PRESCRIBEDMEDICINEID,MEDICINEID) VALUES (:prescribedmedicineid,:medicineId)`;
        const params2 = { prescribedmedicineid, medicineId };
        const result3 = await db_query(query2, params2);
        console.log(result3);
        console.log("medicineId and prescribedmedicineid inserted into relation table");





        res.status(200).json({ message: 'Medicine added to prescription' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

///inserting new medicine into medicine table with prescription id
router.post('/insertNewMedicineIntoMedicineTableFromPrescription', async (req, res) => {
    const { medicineName, genericName, dosage, manufacturer, sideEffects, prescriptionId } = req.body;
    console.log(req.body);
    //get the medicineID from the sequence
    const sequencequery = `SELECT SEQ_MEDICINE_ID.NEXTVAL FROM DUAL`;
    const result1 = await db_query(sequencequery, {});
    const medicineid = result1[0].NEXTVAL;
    console.log("medicine id");
    console.log(medicineid);
    //get prescribemedicineid from sequence
    const sequencequery1 = `SELECT SEQ_PRESCRIBEDMEDICINE_ID.NEXTVAL FROM DUAL`;
    const result2 = await db_query(sequencequery1, {});
    const prescribedmedicineid = result2[0].NEXTVAL;
    console.log("prescribedmedicineid");
    console.log(prescribedmedicineid);

    try {
        const query = `INSERT INTO ALLMEDICINE(MEDICINEID,MEDICINENAME,GENERICNAME,DOSAGES,MANUFACTURER,SIDEEFFECTS) VALUES (:medicineid, :medicineName, :genericName, :dosage, :manufacturer, :sideEffects)`;

        const params = { medicineid, medicineName, genericName, dosage, manufacturer, sideEffects };


        await db_query(query, params);
        console.log("medicine inserted into medicine table");

        const query1 = `INSERT INTO PRESCRIBEDMEDICINE(PRESCRIBEDMEDICINEID,PRESCRIPTIONID) VALUES (:prescribedmedicineid,:prescriptionId)`;
        const params1 = { prescribedmedicineid, prescriptionId };

        await db_query(query1, params1);
        console.log("prescribedmedicineid inserted into prescribedmedicine table");

        const query2 = `INSERT INTO ALLMEDICINEPRESCRIBERMEDICINERELATION(PRESCRIBEDMEDICINEID,MEDICINEID) VALUES (:prescribedmedicineid,:medicineId)`;
        const params2 = { prescribedmedicineid, medicineid };


        await db_query(query2, params2);
        console.log("medicineid and prescribedmedicineid inserted into relation table");

        res.status(200).json({ message: 'Medicine inserted into medicine table with prescription id' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);




//view all advice
router.post('/viewAdvices', async (req, res) => {
    try {
        const query = "SELECT * FROM ADVICES WHERE LOWER(ADVICETYPE)LIKE :adviceType";
        const { adviceType } = req.body;
        const params = { adviceType: `%${adviceType}%` };
        console.log(params);
        //execute the query
        const result = await db_query(query, params);


        if (result.length === 0) {
            res.status(404).json({ error: 'No advice found' });
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

});
//insert advice into prescription
router.post('/insertAdviceIntoPrescription', async (req, res) => {
    //const { prescriptionIdt, medicineIdt } = req.body;
    //convert into number
    const prescriptionId1 = parseInt(req.body.prescriptionId);
    const adviceId1 = parseInt(req.body.adviceId);
    let prescriptionId = prescriptionId1;
    let adviceId = adviceId1;
    console.log("converted id");

    try {
        //const query1 = `INSERT INTO PRESCRIBEDMEDICINE(PRESCRIBEDMEDICINEID,PRESCRIPTIONID) VALUES (SEQ_PRESCRIBEDMEDICINE_ID.NEXTVAL, :prescriptionId)`;
        const sequencequery = `SELECT SEQ_PRESCRIBEDADVICE_ID.NEXTVAL FROM DUAL`;
        const result1 = await db_query(sequencequery, {});
        const prescribedadviceid = result1[0].NEXTVAL;
        console.log(prescribedadviceid);
        const query1 = `INSERT INTO PRESCRIBEDADVICE(PRESCRIBEDADVICEID,PRESCRIPTIONID) VALUES (:prescribedadviceid,:prescriptionId)`;
        const params1 = { prescribedadviceid, prescriptionId };
        const result2 = await db_query(query1, params1);
        console.log(result2);
        const query2 = `INSERT INTO ADVICEPRESCRIBEDADVICERELATION(PRESCRIBEDADVICEID,ADVICEID) VALUES (:prescribedadviceid,:adviceId)`;
        const params2 = { prescribedadviceid, adviceId };
        const result3 = await db_query(query2, params2);
        console.log(result3);
        //send response
        res.status(200).json({ message: 'Advice inserted into prescription' });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);
//inserting new advice into advice table with prescription id
router.post('/insertNewAdviceFromPrescription', async (req, res) => {
    const { adviceType, adviceText, prescriptionId } = req.body;
    console.log(req.body);
    //get the adviceID from the sequence
    const sequencequery = `SELECT SEQ_ADVICE_ID.NEXTVAL FROM DUAL`;
    const result1 = await db_query(sequencequery, {});
    const adviceid = result1[0].NEXTVAL;
    console.log("advice id");
    console.log(adviceid);
    //get prescribemedicineid from sequence
    const sequencequery1 = `SELECT SEQ_PRESCRIBEDADVICE_ID.NEXTVAL FROM DUAL`;
    const result2 = await db_query(sequencequery1, {});
    const prescribedadviceid = result2[0].NEXTVAL;
    console.log("prescribedadviceid");
    console.log(prescribedadviceid);

    try {
        const query = `INSERT INTO ALLADVICES(ADVICEID,ADVICETYPE,ADVICETEXT) VALUES (:adviceid, :adviceType, :adviceText)`;
        const params = { adviceid, adviceType, adviceText };
        const result = await db_query(query, params);
        console.log(result);
        console.log("advice inserted into advice table");
        const query1 = `INSERT INTO PRESCRIBEDADVICE(PRESCRIBEDADVICEID,PRESCRIPTIONID) VALUES (:prescribedadviceid,:prescriptionId)`;
        const params1 = { prescribedadviceid, prescriptionId };
        const result2 = await db_query(query1, params1);
        console.log(result2);
        console.log("prescribedadviceid inserted into prescribedadvice table");
        const query2 = `INSERT INTO ADVICEPRESCRIBEDADVICERELATION(PRESCRIBEDADVICEID,ADVICEID) VALUES (:prescribedadviceid,:adviceId)`;
        const params2 = { prescribedadviceid, adviceid };
        const result3 = await db_query(query2, params2);
        console.log(result3);
        console.log("adviceid and prescribedadviceid inserted into relation table");
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);
//VIEW LAB TESTS
router.post('/viewLabTests', async (req, res) => {
    try {
        const query = "SELECT * FROM LABTESTS  wHERE LOWER(TESTNAME)LIKE :labTestName";

        const { labTestName } = req.body;
        const params = { labTestName: `%${labTestName}%` };
        console.log(params);
        //execute the query
        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(404).json({ error: 'No lab tests found' });
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

});

//insert lab test into prescription
router.post('/insertLabTestIntoPrescription', async (req, res) => {
    //const { prescriptionIdt, medicineIdt } = req.body;
    //convert into number
    const prescriptionId1 = parseInt(req.body.prescriptionId);
    const labTestId1 = parseInt(req.body.labTestId);
    let prescriptionId = prescriptionId1;
    let labTestId = labTestId1;
    console.log("converted id");

    try {
        //const query1 = `INSERT INTO PRESCRIBEDMEDICINE(PRESCRIBEDMEDICINEID,PRESCRIPTIONID) VALUES (SEQ_PRESCRIBEDMEDICINE_ID.NEXTVAL, :prescriptionId)`;
        const sequencequery = `SELECT SEQ_PRESCRIBEDLABTEST_ID.NEXTVAL FROM DUAL`;
        const result1 = await db_query(sequencequery, {});
        const prescribedlabtestid = result1[0].NEXTVAL;
        console.log(prescribedlabtestid);
        const query1 = `INSERT INTO PRESCRIBEDLABTEST(PRESCRIBEDLABTESTID,PRESCRIPTIONID) VALUES (:prescribedlabtestid,:prescriptionId)`;
        const params1 = { prescribedlabtestid, prescriptionId };
        const result2 = await db_query(query1, params1);
        console.log(result2);
        console.log("prescribedlabtestid inserted into prescribedlabtest table");
        const query2 = `INSERT INTO PRESCRIBEDLABTESTALLLABTESTRELATION(PRESCRIBEDLABTESTID,LABTESTID) VALUES (:prescribedlabtestid,:labTestId)`;
        const params2 = { prescribedlabtestid, labTestId };
        const result3 = await db_query(query2, params2);
        console.log(result3);
        console.log("labTestId and prescribedlabtestid inserted into relation table");
        //send response
        res.status(200).json({ message: 'Lab test inserted into prescription' });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);
//inserting new lab test into lab test table with prescription id
router.post('/insertNewLabTestFromPrescription', async (req, res) => {
    const { testName, description, prescriptionId } = req.body;
    console.log(req.body);
    //get the labtestID from the sequence
    const sequencequery = `SELECT SEQ_LABTEST_ID.NEXTVAL FROM DUAL`;
    const result1 = await db_query(sequencequery, {});
    const labtestid = result1[0].NEXTVAL;
    console.log("labtest id");
    console.log(labtestid);
    //get prescribelabtestid from sequence
    const sequencequery1 = `SELECT SEQ_PRESCRIBEDLABTEST_ID.NEXTVAL FROM DUAL`;
    const result2 = await db_query(sequencequery1, {});
    const prescribedlabtestid = result2[0].NEXTVAL;
    console.log("prescribedlabtestid");
    console.log(prescribedlabtestid);

    try {
        const query = `INSERT INTO ALLLABTEST(LABTESTID,TESTNAME,DESCRIPTION) VALUES (:labtestid, :testName, :description)`;
        const params = { labtestid, testName, description };
        const result = await db_query(query, params);
        console.log(result);
        console.log("labtest inserted into labtest table");
        const query1 = `INSERT INTO PRESCRIBEDLABTEST(PRESCRIBEDLABTESTID,PRESCRIPTIONID) VALUES (:prescribedlabtestid,:prescriptionId)`;
        const params1 = { prescribedlabtestid, prescriptionId };
        const result2 = await db_query(query1, params1);
        console.log(result2);
        console.log("prescribedlabtestid inserted into prescribedlabtest table");
        const query2 = `INSERT INTO PRESCRIBEDLABTESTALLLABTESTRELATION(PRESCRIBEDLABTESTID,LABTESTID) VALUES (:prescribedlabtestid,:labTestId)`;
        const params2 = { prescribedlabtestid, labtestid };
        const result3 = await db_query(query2, params2);
        console.log(result3);
        console.log("labtestid and prescribedlabtestid inserted into relation table");

    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);

//add medicine
router.post('/addMedicine', async (req, res) => {
    const { medicineName, genericName, dosage, manufacturer, sideEffects } = req.body;
    console.log(req.body);

    try {
        const query = "INSERT INTO MEDICINES (MEDICINEID, MEDICINENAME, GENERICNAME, DOSAGES, MANUFACTURER, SIDEEFFECTS) " +
            "VALUES (SEQ_MEDICINE_ID.NEXTVAL, :medicineName, :genericName, :dosage, :manufacturer, :sideEffects)";
        const params = { medicineName, genericName, dosage, manufacturer, sideEffects };
        //execute the query
        await db_query(query, params);
        console.log("medicine inserted into medicine table");

    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});
//add lab test
router.post('/addLabTest', async (req, res) => {
    const { testName, description } = req.body;
    console.log(req.body);

    try {
        const query = "INSERT INTO LABTESTS (LABTESTID, TESTNAME, DESCRIPTION) " +
            "VALUES (SEQ_LABTEST_ID.NEXTVAL, :testName, :description)";
        const params = { testName, description };
        //execute the query
        await db_query(query, params);
        console.log("lab test inserted into lab test table");

    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//view patient medicine under a doctor
router.post('/viewPatientsMedicine/:doctorId', async (req, res) => {
    //const { doctorId } = req.params;
    let { patientName, doctorId } = req.body;
    console.log(patientName);
    console.log(doctorId);


    try {
        const query = "SELECT D.FIRSTNAME AS DOCTORNAME,PT.FIRSTNAME AS PATIENTNAME,A.APPOINTMENTID, A.PATIENTID,M.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDMEDICINE PRM ON PRM.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN ALLMEDICINEPRESCRIBERMEDICINERELATION ALPRM ON ALPRM.PRESCRIBEDMEDICINEID=PRM.PRESCRIBEDMEDICINEID JOIN MEDICINES M ON M.MEDICINEID=ALPRM.MEDICINEID WHERE LOWER(PT.FIRSTNAME) LIKE :patientName AND D.DOCTORID=:doctorId AND M.MEDICINENAME IS NOT NULL ORDER BY A.APPOINTMENTID ";
        patientName = patientName.toLowerCase();
        patientName = patientName.trim();
        patientName = `%${patientName}%`;
        console.log("In query");
        console.log(patientName);
        console.log(doctorId);
        const params = { patientName, doctorId };

        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(200).json(result);
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

});
//show taken advices under a doctor
router.post('/viewPatientsAdvice/:doctorId', async (req, res) => {
    //const { doctorId } = req.params;
    let { patientName, doctorId } = req.body;
    console.log(patientName);
    console.log(doctorId);


    try {
        const query = "SELECT D.FIRSTNAME AS DOCTORNAME,PT.FIRSTNAME AS PATIENTNAME,A.APPOINTMENTID, A.PATIENTID,ADV.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDADVICE PRA ON PRA.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN ADVICEPRESCRIBEDADVICERELATION ADR ON PRA.PRESCRIBEDADVICEID=ADR.PRESCRIBEDADVICEID JOIN ADVICES ADV ON ADV.ADVICEID=ADR.ADVICEID WHERE LOWER(PT.FIRSTNAME) LIKE :patientName AND D.DOCTORID=:doctorId ORDER BY A.APPOINTMENTID";
        patientName = patientName.toLowerCase();
        patientName = patientName.trim();
        patientName = `%${patientName}%`;
        console.log("In query");
        console.log(patientName);
        console.log(doctorId);
        const params = { patientName, doctorId };

        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(200).json(result);
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

});

//show taken lab tests under a doctor
router.post('/viewPatientsLabTest/:doctorId', async (req, res) => {
    //const { doctorId } = req.params;
    let { patientName, doctorId } = req.body;
    console.log(patientName);
    console.log(doctorId);
    try {
        const query = "SELECT D.FIRSTNAME AS DOCTORNAME,PT.FIRSTNAME AS PATIENTNAME,A.APPOINTMENTID, A.PATIENTID,PRL.STATUS ,LT.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDLABTEST PRL ON PRL.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN PRESCRIBEDLABTESTALLLABTESTRELATION PRALL ON PRALL.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID JOIN LABTESTS LT ON LT.LABTESTID=PRALL.LABTESTID WHERE LOWER(PT.FIRSTNAME) LIKE :patientName  AND D.DOCTORID=:doctorId ORDER BY A.APPOINTMENTID";
        patientName = patientName.toLowerCase();
        patientName = patientName.trim();
        patientName = `%${patientName}%`;
        console.log("In query");
        console.log(patientName);
        console.log(doctorId);
        const params = { patientName, doctorId };

        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(200).json(result);
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

});
//view lab test result under a doctor
router.post('/viewPatientsLabTestResult/:doctorId', async (req, res) => {
    //const { doctorId } = req.params;
    let { patientName, doctorId } = req.body;
    console.log(patientName);
    console.log(doctorId);
    console.log(doctorId);
    try {
        const query = "SELECT D.FIRSTNAME AS DOCTORNAME,PT.FIRSTNAME AS PATIENTNAME,A.APPOINTMENTID, A.PATIENTID,PRL.STATUS AS TESTSTATUS ,LT.*,R.RESULTDETAILS,R.RESULTDATE FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDLABTEST PRL ON PRL.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN PRESCRIBEDLABTESTALLLABTESTRELATION PRALL ON PRALL.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID JOIN LABTESTS LT ON LT.LABTESTID=PRALL.LABTESTID JOIN RESULT R ON R.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID WHERE PRL.STATUS='TEST COMPLETED' AND LOWER(PT.FIRSTNAME) LIKE :patientName AND D.DOCTORID=:doctorId ORDER BY A.APPOINTMENTID";
        patientName = patientName.toLowerCase();
        patientName = patientName.trim();
        patientName = `%${patientName}%`;
        console.log("In query");
        console.log(patientName);
        console.log(doctorId);
        const params = { patientName, doctorId };

        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(200).json(result);
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

});

//show taken medicines under a doctor on a particular appointment
router.post('/viewPatientsMedicineOnaGivenAppointment/:doctorId', async (req, res) => {
    //const { doctorId } = req.params;
    let { patientName, doctorId, appointmentId } = req.body;
    console.log(patientName);
    console.log(doctorId);
    console.log(appointmentId);
    try {
        const query = "SELECT D.FIRSTNAME AS DOCTORNAME,PT.FIRSTNAME AS PATIENTNAME,A.APPOINTMENTID, A.PATIENTID,M.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDMEDICINE PRM ON PRM.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN ALLMEDICINEPRESCRIBERMEDICINERELATION ALPRM ON ALPRM.PRESCRIBEDMEDICINEID=PRM.PRESCRIBEDMEDICINEID JOIN MEDICINES M ON M.MEDICINEID=ALPRM.MEDICINEID WHERE LOWER(PT.FIRSTNAME) LIKE :patientName AND D.DOCTORID=:doctorId AND A.APPOINTMENTID=:appointmentId AND M.MEDICINENAME IS NOT NULL ORDER BY A.APPOINTMENTID ";
        patientName = patientName.toLowerCase();
        patientName = patientName.trim();
        patientName = `%${patientName}%`;
        console.log("In query");

        console.log(patientName);
        console.log(doctorId);
        console.log(appointmentId);
        const params = { patientName, doctorId, appointmentId };
        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(200).json(result);
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

});


//show taken advices under a doctor on a particular appointment
router.post('/viewPatientsAdviceOnaGivenAppointment/:doctorId', async (req, res) => {
    //const { doctorId } = req.params;
    let { patientName, doctorId, appointmentId } = req.body;
    console.log(patientName);
    console.log(doctorId);
    console.log(appointmentId);

    try {
        const query = "SELECT D.FIRSTNAME AS DOCTORNAME,PT.FIRSTNAME AS PATIENTNAME,A.APPOINTMENTID, A.PATIENTID,ADV.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDADVICE PRA ON PRA.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN ADVICEPRESCRIBEDADVICERELATION ADR ON PRA.PRESCRIBEDADVICEID=ADR.PRESCRIBEDADVICEID JOIN ADVICES ADV ON ADV.ADVICEID=ADR.ADVICEID WHERE LOWER(PT.FIRSTNAME) LIKE :patientName AND D.DOCTORID=:doctorId AND A.APPOINTMENTID=:appointmentId ORDER BY A.APPOINTMENTID";
        patientName = patientName.toLowerCase();
        patientName = patientName.trim();
        patientName = `%${patientName}%`;
        console.log("In query");

        console.log(patientName);
        console.log(doctorId);
        console.log(appointmentId);
        const params = { patientName, doctorId, appointmentId };
        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(200).json(result);
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

});

//show taken lab tests under a doctor on a particular appointment
router.post('/viewPatientsLabTestOnaGivenAppointment/:doctorId', async (req, res) => {
    //const { doctorId } = req.params;
    let { patientName, doctorId, appointmentId } = req.body;
    console.log(patientName);
    console.log(doctorId);
    console.log(appointmentId);
    try {
        const query = "SELECT D.FIRSTNAME AS DOCTORNAME,PT.FIRSTNAME AS PATIENTNAME,A.APPOINTMENTID, A.PATIENTID,PRL.STATUS ,LT.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDLABTEST PRL ON PRL.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN PRESCRIBEDLABTESTALLLABTESTRELATION PRALL ON PRALL.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID JOIN LABTESTS LT ON LT.LABTESTID=PRALL.LABTESTID WHERE LOWER(PT.FIRSTNAME) LIKE :patientName  AND D.DOCTORID=:doctorId AND A.APPOINTMENTID=:appointmentId ORDER BY A.APPOINTMENTID";
        patientName = patientName.toLowerCase();
        patientName = patientName.trim();
        patientName = `%${patientName}%`;
        console.log("In query");
        console.log(patientName);
        console.log(doctorId);
        console.log(appointmentId);
        const params = { patientName, doctorId, appointmentId };
        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(200).json(result);
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

});

//show taken lab test result under a doctor on a particular appointment
router.post('/viewPatientsLabTestResultOnaGivenAppointment/:doctorId', async (req, res) => {
    //const { doctorId } = req.params;
    let { patientName, doctorId, appointmentId } = req.body;
    console.log(patientName);
    console.log(doctorId);
    console.log(appointmentId);
    try {
        const query = "SELECT D.FIRSTNAME AS DOCTORNAME,PT.FIRSTNAME AS PATIENTNAME,A.APPOINTMENTID, A.PATIENTID,PRL.STATUS AS TESTSTATUS ,LT.*,R.RESULTDETAILS,R.RESULTDATE FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDLABTEST PRL ON PRL.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN PRESCRIBEDLABTESTALLLABTESTRELATION PRALL ON PRALL.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID JOIN LABTESTS LT ON LT.LABTESTID=PRALL.LABTESTID JOIN RESULT R ON R.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID WHERE PRL.STATUS='TEST COMPLETED' AND LOWER(PT.FIRSTNAME) LIKE :patientName AND D.DOCTORID=:doctorId AND A.APPOINTMENTID=:appointmentId ORDER BY A.APPOINTMENTID";
        patientName = patientName.toLowerCase();
        patientName = patientName.trim();
        patientName = `%${patientName}%`;
        console.log("In query");
        console.log(patientName);
        console.log(doctorId);
        console.log(appointmentId);
        const params = { patientName, doctorId, appointmentId };
        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(200).json(result);
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

});




//inserting doctor fee into prescription
router.post('/insertDoctorFeeIntoPrescription', async (req, res) => {
    //const { prescriptionIdt, medicineIdt } = req.body;
    //convert into number
    const prescriptionId1 = parseInt(req.body.prescriptionId);
    const doctorFee1 = parseInt(req.body.doctorFee);
    let prescriptionId = prescriptionId1;
    let doctorFee = doctorFee1;
    console.log("converted id");

    try {
        const sequencequery = `SELECT SEQ_DOCTORBILL_ID.NEXTVAL FROM DUAL`;
        const result1 = await db_query(sequencequery, {});
        const doctorbillid = result1[0].NEXTVAL;
        console.log(doctorbillid);
        const query1 = `INSERT INTO DOCTORBILL(DOCTORBILLID,PRESCRIPTIONID,DOCTORCOST) VALUES (:doctorbillid,:prescriptionId,:doctorFee)`;
        const params1 = { doctorbillid, prescriptionId, doctorFee };
        const result2 = await db_query(query1, params1);
        console.log(result2);
        console.log("doctorbillid inserted into doctorbill table");
        const sequencequery1 = `SELECT SEQ_BILLID.NEXTVAL FROM DUAL`;
        const result3 = await db_query(sequencequery1, {});
        const billid = result3[0].NEXTVAL;
        console.log(billid);
        const query2 = `INSERT INTO BILL(BILLID,PRESCRIPTIONID) VALUES (:billid,:prescriptionId)`;
        const params2 = { billid, prescriptionId };
        const result4 = await db_query(query2, params2);
        console.log(result4);
        //send response
        res.status(200).json({ message: 'Doctor fee inserted into prescription' });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);

//see pending lab test
router.post('/seePendingLabTests', async (req, res) => {

    //convert into number
    const appointmentId1 = parseInt(req.body.appointmentId);
    let appointmentId = appointmentId1;


    try {
        const query = "SELECT A.PATIENTID,A.APPOINTMENTID,LB.LABTESTID,LB.TESTNAME,LB.DESCRIPTION,PRT.STATUS,PRT.PRESCRIBEDLABTESTID,PRT.PRESCRIPTIONID FROM APPOINTMENT A JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDLABTEST PRT ON P.PRESCRIPTIONID=PRT.PRESCRIPTIONID JOIN PRESCRIBEDLABTESTALLLABTESTRELATION PRALL ON PRALL.PRESCRIBEDLABTESTID=PRT.PRESCRIBEDLABTESTID JOIN LABTESTS LB ON LB.LABTESTID=PRALL.LABTESTID WHERE A.APPOINTMENTID=:appointmentId AND PRT.STATUS='TEST PENDING'";
        const params = { appointmentId };

        const result = await db_query(query, params);

        if (result.length === 0) {
            res.status(200).json(result);
        } else {
            res.status(200).json(result);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

});

//conduct lab test
router.post('/conductLabTest', async (req, res) => {
    //const { prescriptionIdt, medicineIdt } = req.body;
    //convert into number
    const { result, cost, labTest } = req.body;
    console.log(result);
    console.log(cost);
    console.log(labTest);
    //get PRESCRIBEDLABTESTID,PATIENTID,LABTESTID,PRESCRIPTIONID from lab test
    //get these from lab test object
    const prescribedlabtestid = labTest.PRESCRIBEDLABTESTID;
    const patientid = labTest.PATIENTID;
    const labtestid = labTest.LABTESTID;
    const prescriptionid = labTest.PRESCRIPTIONID;
    console.log(prescribedlabtestid);
    console.log(patientid);
    console.log(labtestid);
    console.log(prescriptionid);
    //cobvert cost into number
    const cost1 = parseInt(cost);



    try {
        const sequencequery = `SELECT LABBILL_ID.NEXTVAL FROM DUAL`;
        const result1 = await db_query(sequencequery, {});
        const labbillid = result1[0].NEXTVAL;
        console.log(labbillid);
        const sequencequery1 = `SELECT RESULT_ID.NEXTVAL FROM DUAL`;
        const result2 = await db_query(sequencequery1, {});
        const resultid = result2[0].NEXTVAL;
        console.log(resultid);
        const query1 = `INSERT INTO LABBILL(LABBILLID,PRESCRIPTIONID,LABTESTID,COST) VALUES (:labbillid,:prescriptionid,:labtestid,:cost1)`;
        const params1 = { labbillid, prescriptionid, labtestid, cost1 };
        const result3 = await db_query(query1, params1);
        console.log(result3);
        console.log("labbillid inserted into labbill table");
        const query2 = `INSERT INTO RESULT (RESULTID,PATIENTID,RESULTDETAILS,PRESCRIBEDLABTESTID,LABTESTID) VALUES (:resultid,:patientid,:result,:prescribedlabtestid,:labtestid)`;
        const params2 = { resultid, patientid, result, prescribedlabtestid, labtestid };
        const result4 = await db_query(query2, params2);
        console.log(result4);
        console.log("resultid inserted into result table");
        const query3 = `UPDATE PRESCRIBEDLABTEST SET STATUS='TEST COMPLETED' WHERE PRESCRIBEDLABTESTID=:prescribedlabtestid`;
        const params3 = { prescribedlabtestid };
        const result5 = await db_query(query3, params3);
        console.log(result5);
        console.log("status updated in prescribedlabtest table");
        //send response
        res.status(200).json({ message: 'Lab test conducted successfully' });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);

//lab test payment
router.post('/labTestForPayment', async (req, res) => {
    //convert into number
    const appointmentId1 = parseInt(req.body.appointmentId);
    let appointmentId = appointmentId1;
    try {
        const query = "SELECT A.APPOINTMENTID,LT.*,LB.COST FROM APPOINTMENT A JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN LABBILL LB ON LB.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN LABTESTS LT ON LT.LABTESTID=LB.LABTESTID WHERE A.APPOINTMENTID=:appointmentId AND P.PRESCRIPTION_STATUS='UNPAID'";
        const params = { appointmentId };
        const result = await db_query(query, params);
        if (result.length === 0) {
            res.status(200).json(result);
        }
        else {
            res.status(200).json(result);
        }

    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
    
});

//doctor fee payment
router.post('/doctorPayment', async (req, res) => {
    //convert into number
    const appointmentId1 = parseInt(req.body.appointmentId);
    let appointmentId = appointmentId1;
    try {
        const query = "SELECT A.APPOINTMENTID, DC.FIRSTNAME || ' ' || DC.LASTNAME AS DOCTORNAME,DB.DOCTORCOST AS FEE FROM APPOINTMENT A JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN DOCTORBILL DB ON DB.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN DOCTOR DC ON A.DOCTORID=DC.DOCTORID WHERE A.APPOINTMENTID=:appointmentId AND P.PRESCRIPTION_STATUS='UNPAID'";
        const params = { appointmentId };
        const result = await db_query(query, params);
        if (result.length === 0) {
            res.status(200).json(result);
        }
        else {
            res.status(200).json(result);
        }

    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
    
}
);

//total payment
router.post('/totalPayment', async (req, res) => {
    //convert into number
    const appointmentId1 = parseInt(req.body.appointmentId);
    let appointmentId = appointmentId1;
    try {
        const query = "SELECT NVL(SUM(COST),0) AS LABCOST,NVL(SUM(DOCTORCOST),0) AS DOCTORCOST ,NVL(SUM(COST),0)+NVL(SUM(DOCTORCOST),0) AS TOTALCOST  FROM APPOINTMENT A JOIN PRESCRIPTION P ON A.APPOINTMENTID = P.APPOINTMENTID  LEFT JOIN (SELECT PRESCRIPTIONID, SUM(COST) AS COST FROM LABBILL GROUP BY PRESCRIPTIONID  ) LB ON LB.PRESCRIPTIONID = P.PRESCRIPTIONID LEFT  JOIN ( SELECT PRESCRIPTIONID, SUM(DOCTORCOST) AS DOCTORCOST FROM DOCTORBILL GROUP BY PRESCRIPTIONID ) DB ON DB.PRESCRIPTIONID = P.PRESCRIPTIONID WHERE A.APPOINTMENTID =:appointmentId AND P.PRESCRIPTION_STATUS = 'UNPAID'";
        const params = { appointmentId };
        const result = await db_query(query, params);
        if (result.length === 0) {
            res.status(200).json(result);
        }
        else {
            res.status(200).json(result);
        }

    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
    
}
);

//pay verification
router.post('/payVerification', async (req, res) => {
    //convert into number
    const appointmentId1 = parseInt(req.body.appointmentId);
    let appointmentId = appointmentId1;
    const amount1 = parseInt(req.body.amount);
    let amount = amount1;
    try {
        // const query = "UPDATE PRESCRIPTION SET PRESCRIPTION_STATUS='PAID' WHERE PRESCRIPTION_STATUS='UNPAID' AND APPOINTMENTID=:appointmentId";
        // const params = { appointmentId };
        // const result = await db_query(query, params);
        const query1 = "SELECT NVL(SUM(COST),0) AS LABCOST,NVL(SUM(DOCTORCOST),0) AS DOCTORCOST ,NVL(SUM(COST),0)+NVL(SUM(DOCTORCOST),0) AS TOTALCOST  FROM APPOINTMENT A JOIN PRESCRIPTION P ON A.APPOINTMENTID = P.APPOINTMENTID  LEFT JOIN (SELECT PRESCRIPTIONID, SUM(COST) AS COST FROM LABBILL GROUP BY PRESCRIPTIONID  ) LB ON LB.PRESCRIPTIONID = P.PRESCRIPTIONID LEFT  JOIN ( SELECT PRESCRIPTIONID, SUM(DOCTORCOST) AS DOCTORCOST FROM DOCTORBILL GROUP BY PRESCRIPTIONID ) DB ON DB.PRESCRIPTIONID = P.PRESCRIPTIONID WHERE A.APPOINTMENTID =:appointmentId AND P.PRESCRIPTION_STATUS = 'UNPAID'";
        const params1 = { appointmentId };
        const result1 = await db_query(query1, params1);
        console.log("In pay verification");
        console.log(result1);
        const totalCost=result1[0].TOTALCOST;
        console.log(totalCost);
        if(totalCost<=amount){
            const query = "UPDATE PRESCRIPTION SET PRESCRIPTION_STATUS='PAID' WHERE PRESCRIPTION_STATUS='UNPAID' AND APPOINTMENTID=:appointmentId";
            const params = { appointmentId };
            const result = await db_query(query, params);
            res.status(200).json({message:'Payment Successful'});
        }
        else{
            res.status(400).json({message:'Payment Unsuccessful'});
        }

    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
    
}
);

//see given medicine from patient
router.post('/prescription/getAllGivenMedicine', async (req, res) => {
    //get the patient id from the request
    const { patientId } = req.body;
    console.log(patientId);
    //convert into number
    const patientId1 = parseInt(patientId);
    try{
        const query = "SELECT PT.FIRSTNAME AS PATIENTNAME,D.FIRSTNAME AS DOCTORNAME,A.APPOINTMENTID, A.PATIENTID,M.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDMEDICINE PRM ON PRM.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN ALLMEDICINEPRESCRIBERMEDICINERELATION ALPRM ON ALPRM.PRESCRIBEDMEDICINEID=PRM.PRESCRIBEDMEDICINEID JOIN MEDICINES M ON M.MEDICINEID=ALPRM.MEDICINEID WHERE PT.PATIENT_ID=:patientId AND P.PRESCRIPTION_STATUS='PAID' ORDER BY A.APPOINTMENTID";
        const params = { patientId: patientId1 };
        const result = await db_query(query, params);
        if (result.length === 0) {
            res.status(200).json(result);
        }
        else {
            res.status(200).json(result);
        }
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);

//see given advice from patient
router.post('/prescription/getAllGivenAdvice', async (req, res) => {
    //get the patient id from the request
    const { patientId } = req.body;
    console.log(patientId);
    //convert into number
    const patientId1 = parseInt(patientId);
    try{
        const query = "SELECT PT.FIRSTNAME AS PATIENTNAME,D.FIRSTNAME AS DOCTORNAME,A.APPOINTMENTID, A.PATIENTID,ADV.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDADVICE PRA ON PRA.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN ADVICEPRESCRIBEDADVICERELATION ADR ON PRA.PRESCRIBEDADVICEID=ADR.PRESCRIBEDADVICEID JOIN ADVICES ADV ON ADV.ADVICEID=ADR.ADVICEID WHERE PT.PATIENT_ID=:patientId AND P.PRESCRIPTION_STATUS='PAID' ORDER BY A.APPOINTMENTID";
        const params = { patientId: patientId1 };
        const result = await db_query(query, params);
        if (result.length === 0) {
            res.status(200).json(result);
        }
        else {
            res.status(200).json(result);
        }
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);

//see given lab test from patient
router.post('/prescription/getAllGivenTests', async (req, res) => {
    //get the patient id from the request
    const { patientId } = req.body;
    console.log(patientId);
    //convert into number
    const patientId1 = parseInt(patientId);
    try{
        const query = "SELECT PT.FIRSTNAME AS PATIENTNAME,D.FIRSTNAME AS DOCTORNAME,A.APPOINTMENTID, A.PATIENTID,PRL.STATUS ,LT.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDLABTEST PRL ON PRL.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN PRESCRIBEDLABTESTALLLABTESTRELATION PRALL ON PRALL.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID JOIN LABTESTS LT ON LT.LABTESTID=PRALL.LABTESTID WHERE PT.PATIENT_ID=:patientId AND P.PRESCRIPTION_STATUS='PAID' ORDER BY A.APPOINTMENTID";
        const params = { patientId: patientId1 };
        const result = await db_query(query, params);
        if (result.length === 0) {
            res.status(200).json(result);
        }
        else {
            res.status(200).json(result);
        }
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);

//see given lab test result from patient
router.post('/prescription/getAllGivenTestResults', async (req, res) => {
    //get the patient id from the request
    const { patientId } = req.body;
    console.log(patientId);
    //convert into number
    const patientId1 = parseInt(patientId);
    try{
        const query = "SELECT PT.FIRSTNAME AS PATIENTNAME, D.FIRSTNAME AS DOCTORNAME,A.APPOINTMENTID, A.PATIENTID,LT.*,R.RESULTDETAILS,R.RESULTDATE FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDLABTEST PRL ON PRL.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN PRESCRIBEDLABTESTALLLABTESTRELATION PRALL ON PRALL.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID JOIN LABTESTS LT ON LT.LABTESTID=PRALL.LABTESTID JOIN RESULT R ON R.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID WHERE PRL.STATUS='TEST COMPLETED' AND PT.PATIENT_ID=:patientId AND P.PRESCRIPTION_STATUS='PAID' ORDER BY A.APPOINTMENTID";
        const params = { patientId: patientId1 };
        const result = await db_query(query, params);
        if (result.length === 0) {
            res.status(200).json(result);
        }
        else {
            res.status(200).json(result);
        }
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);

//see all given medicine from patient for a particular appointment
router.post('/prescription/getAllGivenMedicineOnaGivenAppointment', async (req, res) => {
    //get the patient id from the request
    const { patientId, appointmentId } = req.body;
    console.log(patientId);
    console.log(appointmentId);
    //convert into number
    const patientId1 = parseInt(patientId);
    const appointmentId1 = parseInt(appointmentId);
    try{
        const query = "SELECT PT.FIRSTNAME AS PATIENTNAME,D.FIRSTNAME AS DOCTORNAME,A.APPOINTMENTID, A.PATIENTID,M.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDMEDICINE PRM ON PRM.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN ALLMEDICINEPRESCRIBERMEDICINERELATION ALPRM ON ALPRM.PRESCRIBEDMEDICINEID=PRM.PRESCRIBEDMEDICINEID JOIN MEDICINES M ON M.MEDICINEID=ALPRM.MEDICINEID WHERE PT.PATIENT_ID=:patientId AND P.PRESCRIPTION_STATUS='PAID' AND A.APPOINTMENTID=:appointmentId AND M.MEDICINENAME IS NOT NULL ORDER BY A.APPOINTMENTID";
        const params = { patientId: patientId1, appointmentId: appointmentId1 };
        const result = await db_query(query, params);
        if (result.length === 0) {
            res.status(200).json(result);
        }
        else {
            res.status(200).json(result);
        }
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);

//see all given advice from patient for a particular appointment
router.post('/prescription/getAllGivenAdviceOnaGivenAppointment', async (req, res) => {
    //get the patient id from the request
    const { patientId, appointmentId } = req.body;
    console.log(patientId);
    console.log(appointmentId);
    //convert into number
    const patientId1 = parseInt(patientId);
    const appointmentId1 = parseInt(appointmentId);
    try{
        const query = "SELECT PT.FIRSTNAME AS PATIENTNAME,D.FIRSTNAME AS DOCTORNAME,A.APPOINTMENTID, A.PATIENTID,ADV.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDADVICE PRA ON PRA.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN ADVICEPRESCRIBEDADVICERELATION ADR ON PRA.PRESCRIBEDADVICEID=ADR.PRESCRIBEDADVICEID JOIN ADVICES ADV ON ADV.ADVICEID=ADR.ADVICEID WHERE PT.PATIENT_ID=:patientId AND P.PRESCRIPTION_STATUS='PAID' AND A.APPOINTMENTID=:appointmentId  ORDER BY A.APPOINTMENTID";
        const params = { patientId: patientId1, appointmentId: appointmentId1 };
        const result = await db_query(query, params);
        if (result.length === 0) {
            res.status(200).json(result);
        }
        else {
            res.status(200).json(result);
        }
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);
//see all given lab test from patient for a particular appointment
router.post('/prescription/getAllGivenTestsOnaGivenAppointment', async (req, res) => {
    //get the patient id from the request
    const { patientId, appointmentId } = req.body;
    console.log(patientId);
    console.log(appointmentId);
    //convert into number
    const patientId1 = parseInt(patientId);
    const appointmentId1 = parseInt(appointmentId);
    try{
        const query = "SELECT D.FIRSTNAME AS DOCTORNAME,PT.FIRSTNAME AS PATIENTNAME,A.APPOINTMENTID, A.PATIENTID,PRL.STATUS ,LT.* FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDLABTEST PRL ON PRL.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN PRESCRIBEDLABTESTALLLABTESTRELATION PRALL ON PRALL.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID JOIN LABTESTS LT ON LT.LABTESTID=PRALL.LABTESTID WHERE PT.PATIENT_ID=:patientId AND P.PRESCRIPTION_STATUS='PAID' AND A.APPOINTMENTID=:appointmentId  ORDER BY A.APPOINTMENTID";
        const params = { patientId: patientId1, appointmentId: appointmentId1 };
        const result = await db_query(query, params);
        if (result.length === 0) {
            res.status(200).json(result);
        }
        else {
            res.status(200).json(result);
        }
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);

//see all given lab test result from patient for a particular appointment
router.post('/prescription/getAllGivenTestResultsOnaGivenAppointment', async (req, res) => {
    //get the patient id from the request
    const { patientId, appointmentId } = req.body;
    console.log(patientId);
    console.log(appointmentId);
    //convert into number
    const patientId1 = parseInt(patientId);
    const appointmentId1 = parseInt(appointmentId);
    try{
        const query = "SELECT PT.FIRSTNAME AS PATIENTNAME, D.FIRSTNAME AS DOCTORNAME,A.APPOINTMENTID, A.PATIENTID,LT.*,R.RESULTDETAILS,R.RESULTDATE FROM DOCTOR D JOIN APPOINTMENT A ON A.DOCTORID=D.DOCTORID JOIN PATIENT PT ON PT.PATIENT_ID=A.PATIENTID JOIN PRESCRIPTION P ON A.APPOINTMENTID=P.APPOINTMENTID JOIN PRESCRIBEDLABTEST PRL ON PRL.PRESCRIPTIONID=P.PRESCRIPTIONID JOIN PRESCRIBEDLABTESTALLLABTESTRELATION PRALL ON PRALL.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID JOIN LABTESTS LT ON LT.LABTESTID=PRALL.LABTESTID JOIN RESULT R ON R.PRESCRIBEDLABTESTID=PRL.PRESCRIBEDLABTESTID WHERE PRL.STATUS='TEST COMPLETED' AND PT.PATIENT_ID=:patientId AND A.APPOINTMENTID=:appointmentId  AND P.PRESCRIPTION_STATUS='PAID' ORDER BY A.APPOINTMENTID";
        const params = { patientId: patientId1, appointmentId: appointmentId1 };
        const result = await db_query(query, params);
        if (result.length === 0) {
            res.status(200).json(result);
        }
        else {
            res.status(200).json(result);
        }
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
);

app.listen(3000, () => {
    console.log('Server on port 3000');
});

module.exports = app;
module.exports = router;




