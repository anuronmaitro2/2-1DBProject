const urlParams = new URLSearchParams(window.location.search);
let doctorId = urlParams.get('doctorId');
//convert to number
const doctorId1 = parseInt(doctorId);
doctorId=doctorId1;

let isLoggedIn = false;
const login = async () => {
 
  // Check if doctor ID is not empty
  if (doctorId != "") {
    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ doctorId: parseInt(doctorId) }),
    };
    try {
      const url = `http://localhost:3000/loginAsADoctor/${doctorId}`;
      console.log("In dashboardDoctor.js");
      console.log(url);
      console.log(doctorId);
      const response = await fetch(url, options);

      // Check if the response is successful (status code 200-299)
      if (response.ok) {
        const contentType = response.headers.get("content-type");

        // Check if the response is JSON
        if (contentType && contentType.includes("application/json")) {
          const doctorInfo = await response.json();
          console.log(doctorInfo);
          isLoggedIn = true;
          // Display doctor information
          displayDoctorInfo(doctorInfo[0]);
        } else {
          // Handle the case when the response is not JSON
          console.error("Unexpected response format: Not JSON");
        }
      } else {
        // Handle the case when the response status is not OK
        console.error("Request failed with status:", response.status);
      }
    } catch (error) {
      console.error(error);
    }
  }
};
const displayDoctorInfo = (doctorInfo) => {
    const doctorInfoDiv = document.getElementById("doctorInfo");
    doctorInfoDiv.innerHTML = "";
    // Display data in a table
    const table = document.createElement("table");
    // Add table header row
    const tableHeader = document.createElement("tr");
    for (const key in doctorInfo) {
      const tableHeaderCell = document.createElement("th");
      tableHeaderCell.textContent = key;
      tableHeader.appendChild(tableHeaderCell);
    }
    table.appendChild(tableHeader);
    // Add table row
    const tableRow = document.createElement("tr");
    for (const key in doctorInfo) {
      const tableCell = document.createElement("td");
      tableCell.textContent = doctorInfo[key];
      tableRow.appendChild(tableCell);
    }
    table.appendChild(tableRow);
    doctorInfoDiv.appendChild(table);
  };
  
  
  
  //view appointment as a doctor
  
  const viewAppointments = async () => {
    if (isLoggedIn === false) {
      alert("Please login first");
    }
    console.log(doctorId);
    // Check if doctor ID is not empty
    if (doctorId != "") {
      const options = {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      };
      try {
        const url = `http://localhost:3000/viewAppointments/${doctorId}`;
        console.log(url);
        console.log(doctorId);
        const response = await fetch(url, options);
  
        // Check if the response is successful (status code 200-299)
        if (response.ok) {
          const contentType = response.headers.get("content-type");
  
          // Check if the response is JSON
          if (contentType && contentType.includes("application/json")) {
            const appointments = await response.json();
            console.log(appointments);
            // Display appointments information
            displayAppointments(appointments);
          } else {
            // Handle the case when the response is not JSON
            console.error("Unexpected response format: Not JSON");
          }
        } else {
          // Handle the case when the response status is not OK
          console.error("Request failed with status:", response.status);
        }
      } catch (error) {
        console.error(error);
      }
    }
  };
  
  const displayAppointments = (appointments) => {
    if(appointments.length===0){
      //show in html that no appointments are there
      const doctorInfoDiv = document.getElementById("appointmentsTable");
      doctorInfoDiv.innerHTML = "NO APPOINTMENTS";
      return;
      //just show no appointments in div
      //no need to show table

    }
  
    const doctorInfoDiv = document.getElementById("appointmentsTable");
    doctorInfoDiv.innerHTML = "";
    // Display data in a table
    const table = document.createElement("table");
    // Add table header row
    const tableHeader = document.createElement("tr");
    for (const key in appointments[0]) {
      const tableHeaderCell = document.createElement("th");
      tableHeaderCell.textContent = key;
      tableHeader.appendChild(tableHeaderCell);
    }
    const approveButtonHeaderCell = document.createElement("th");
    approveButtonHeaderCell.textContent = "Approve";
    tableHeader.appendChild(approveButtonHeaderCell);
    table.appendChild(tableHeader);
    // Add table rows with data
    for (const appointment of appointments) {
      const tableRow = document.createElement("tr");
      for (const key in appointment) {
        const tableCell = document.createElement("td");
        tableCell.textContent = appointment[key];
        tableRow.appendChild(tableCell);
      }
      // Add a cell for the "Approve" button
      const approveButtonCell = document.createElement("td");
      const approveButton = document.createElement("button");
      approveButton.textContent = "Approve";
      approveButton.addEventListener("click", () => {
        approveAppointment(appointment.APPOINTMENTID);
      });
      approveButtonCell.appendChild(approveButton);
      tableRow.appendChild(approveButtonCell);
      table.appendChild(tableRow);
    }
    doctorInfoDiv.appendChild(table);
  };
  
  ////approve appointment
  
  
  const approveAppointment = async (appointmentId) => {
    // Send a request to update the appointment status to "APPROVED"
    const options = {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ status: "APPROVED" }),
    };
  
    try {
      const url = `http://localhost:3000/approveAppointment/${appointmentId}`;
      const response = await fetch(url, options);
  
      if (response.ok) {
        alert("Appointment approved successfully!");
        // If the update is successful, navigate to the prescription page
        window.location.href = `prescription.html?appointmentId=${appointmentId}`;
      } else {
        console.error("Request failed with status:", response.status);
      }
    } catch (error) {
      console.error(error);
    }
  };
    //show patients medicine under the doctor
    const showTakenMedicine = async () => {
      if (isLoggedIn === false) {
        alert("Please login first");
      }
      console.log(doctorId);
      //take patient name from html
      const patientName = document.getElementById("patientName").value;
      // Check if doctor ID is not empty
      if (doctorId != "") {
        const options = {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ patientName: patientName, doctorId: parseInt(doctorId)}),
        };
        try {
          const url = `http://localhost:3000/viewPatientsMedicine/${doctorId}`;
          console.log(url);
          console.log(doctorId);
          const response = await fetch(url, options);
    
          // Check if the response is successful (status code 200-299)
          if (response.ok) {
            const contentType = response.headers.get("content-type");
    
            // Check if the response is JSON
            if (contentType && contentType.includes("application/json")) {
              const medicine = await response.json();
              console.log("Response from server:");
              console.log(medicine);
              // Display medicine information
              displayMedicine(medicine);
            } else {
              // Handle the case when the response is not JSON
              console.error("Unexpected response format: Not JSON");
            }
          } else {
            // Handle the case when the response status is not OK
            console.error("Request failed with status:", response.status);
          }
        } catch (error) {
          console.error(error);
        }
      }
    };
    //display medicine
    //show the result in a table
    const displayMedicine = (medicines) => {
      if(medicines.length===0){
        //show in html that no appointments are there
        const doctorInfoDiv = document.getElementById("takenMedicine");
        doctorInfoDiv.innerHTML = "NO MEDICINE";
        return;
        //just show no appointments in div
        //no need to show table
  
      }
    
      const doctorInfoDiv = document.getElementById("takenMedicine");
      doctorInfoDiv.innerHTML = "";
      // Display data in a table
      const table = document.createElement("table");
      // Add table header row
      const tableHeader = document.createElement("tr");
      for (const key in medicines[0]) {
        const tableHeaderCell = document.createElement("th");
        tableHeaderCell.textContent = key;
        tableHeader.appendChild(tableHeaderCell);
      }
      table.appendChild(tableHeader);
      // Add table rows with data
      for (const medicine of medicines) {
        const tableRow = document.createElement("tr");
        for (const key in medicine) {
          const tableCell = document.createElement("td");
          tableCell.textContent = medicine[key];
          tableRow.appendChild(tableCell);
        }
        table.appendChild(tableRow);
      }
      //add a header naming given medicine
      const header = document.createElement("h3");
      header.textContent = "Given Medicine";
      doctorInfoDiv.appendChild(header);
      doctorInfoDiv.appendChild(table);
    };
    //show taken advice
    const showTakenAdvice = async () => {
      if (isLoggedIn === false) {
        alert("Please login first");
      }
      console.log(doctorId);
      //take patient name from html
      const patientName = document.getElementById("patientName").value;
      // Check if doctor ID is not empty
      if (doctorId != "") {
        const options = {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ patientName: patientName, doctorId: parseInt(doctorId)}),
        };
        try {
          const url = `http://localhost:3000/viewPatientsAdvice/${doctorId}`;
          console.log(url);
          console.log(doctorId);
          const response = await fetch(url, options);
          console.log(response);
    
          // Check if the response is successful (status code 200-299)
          if (response.ok) {
            const contentType = response.headers.get("content-type");
    
            // Check if the response is JSON
            if (contentType && contentType.includes("application/json")) {
              const advice = await response.json();
              console.log("Response from server:");
              console.log(advice);
              // Display advice information
              displayAdvice(advice);
            } else {
              // Handle the case when the response is not JSON
              console.error("Unexpected response format: Not JSON");
            }
          } else {
            // Handle the case when the response status is not OK
            console.error("Request failed with status:", response.status);
          }
        } catch (error) {
          console.error(error);
        }
      }
    };
    //display advice
    //show the result in a table
    const displayAdvice = (advices) => {
      if(advices.length===0){
        //show in html that no appointments are there
        const doctorInfoDiv = document.getElementById("takenAdvices");
        doctorInfoDiv.innerHTML = "NO ADVICE";
        return;
        //just show no appointments in div
        //no need to show table
  
      }
    
      const doctorInfoDiv = document.getElementById("takenAdvices");
      doctorInfoDiv.innerHTML = "";
      // Display data in a table
      const table = document.createElement("table");
      // Add table header row
      const tableHeader = document.createElement("tr");
      for (const key in advices[0]) {
        const tableHeaderCell = document.createElement("th");
        tableHeaderCell.textContent = key;
        tableHeader.appendChild(tableHeaderCell);
      }
      table.appendChild(tableHeader);
      // Add table rows with data
      for (const advice of advices) {
        const tableRow = document.createElement("tr");
        for (const key in advice) {
          const tableCell = document.createElement("td");
          tableCell.textContent = advice[key];
          tableRow.appendChild(tableCell);
        }
        table.appendChild(tableRow);
      }
      //add a header naming given medicine
      const header = document.createElement("h3");
      header.textContent = "Given Advice";
      doctorInfoDiv.appendChild(header);
      doctorInfoDiv.appendChild(table);
    };

  //show taken lab test
  const showTakenLabTest = async () => {
    if (isLoggedIn === false) {
      alert("Please login first");
    }
    console.log(doctorId);
    //take patient name from html
    const patientName = document.getElementById("patientName").value;
    // Check if doctor ID is not empty
    if (doctorId != "") {
      const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ patientName: patientName, doctorId: parseInt(doctorId)}),
      };
      try {
        const url = `http://localhost:3000/viewPatientsLabTest/${doctorId}`;
        console.log(url);
        console.log(doctorId);
        const response = await fetch(url, options);
        console.log(response);

        // Check if the response is successful (status code 200-299)
        if (response.ok) {
          const contentType = response.headers.get("content-type");

          // Check if the response is JSON
          if (contentType && contentType.includes("application/json")) {
            const labTest = await response.json();
            console.log("Response from server:");
            console.log(labTest);
            // Display advice information
            displayLabTest(labTest);
          } else {
            // Handle the case when the response is not JSON
            console.error("Unexpected response format: Not JSON");
          }
        } else {
          // Handle the case when the response status is not OK
          console.error("Request failed with status:", response.status);
        }
      } catch (error) {
        console.error(error);
      }
    }
  };
  //display lab test
  //show the result in a table
  const displayLabTest = (labTests) => {
    if(labTests.length===0){
      //show in html that no appointments are there
      const doctorInfoDiv = document.getElementById("takenLabTests");
      doctorInfoDiv.innerHTML = "NO LAB TEST";
      return;
      //just show no appointments in div
      //no need to show table

    }
  
    const doctorInfoDiv = document.getElementById("takenLabTests");
    doctorInfoDiv.innerHTML = "";
    // Display data in a table
    const table = document.createElement("table");
    // Add table header row
    const tableHeader = document.createElement("tr");
    for (const key in labTests[0]) {
      const tableHeaderCell = document.createElement("th");
      tableHeaderCell.textContent = key;
      tableHeader.appendChild(tableHeaderCell);
    }
    table.appendChild(tableHeader);
    // Add table rows with data
    for (const labTest of labTests) {
      const tableRow = document.createElement("tr");
      for (const key in labTest) {
        const tableCell = document.createElement("td");
        tableCell.textContent = labTest[key];
        tableRow.appendChild(tableCell);
      }
      table.appendChild(tableRow);
    }
    //add a header naming given medicine
    const header = document.createElement("h3");
    header.textContent = "Given Lab Test";
    doctorInfoDiv.appendChild(header);
    doctorInfoDiv.appendChild(table);
  };
  //show taken lab test result
  const showTakenLabTestResult = async () => {
    if (isLoggedIn === false) {
      alert("Please login first");
    }
    console.log(doctorId);
    //take patient name from html
    const patientName = document.getElementById("patientName").value;
    // Check if doctor ID is not empty
    if (doctorId != "") {
      const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ patientName: patientName, doctorId: parseInt(doctorId)}),
      };
      try {
        const url = `http://localhost:3000/viewPatientsLabTestResult/${doctorId}`;
        console.log(url);
        console.log(doctorId);
        const response = await fetch(url, options);
        console.log(response);

        // Check if the response is successful (status code 200-299)
        if (response.ok) {
          const contentType = response.headers.get("content-type");

          // Check if the response is JSON
          if (contentType && contentType.includes("application/json")) {
            const labTestResult = await response.json();
            console.log("Response from server:");
            console.log(labTestResult);
            // Display advice information
            displayLabTestResult(labTestResult);
          } else {
            // Handle the case when the response is not JSON
            console.error("Unexpected response format: Not JSON");
          }
        } else {
          // Handle the case when the response status is not OK
          console.error("Request failed with status:", response.status);
        }
      } catch (error) {
        console.error(error);
      }
    }
  };
  //display lab test result
  //show the result in a table
  const displayLabTestResult = (labTestResults) => {
    if(labTestResults.length===0){
      //show in html that no appointments are there
      const doctorInfoDiv = document.getElementById("resultofCompletedLabTests");
      doctorInfoDiv.innerHTML = "NO LAB TEST RESULT";
      return;
      //just show no appointments in div
      //no need to show table

    }
  
    const doctorInfoDiv = document.getElementById("resultofCompletedLabTests");
    doctorInfoDiv.innerHTML = "";
    // Display data in a table
    const table = document.createElement("table");
    // Add table header row
    const tableHeader = document.createElement("tr");
    for (const key in labTestResults[0]) {
      const tableHeaderCell = document.createElement("th");
      tableHeaderCell.textContent = key;
      tableHeader.appendChild(tableHeaderCell);
    }
    table.appendChild(tableHeader);
    // Add table rows with data
    for (const labTestResult of labTestResults) {
      const tableRow = document.createElement("tr");
      for (const key in labTestResult) {
        const tableCell = document.createElement("td");
        tableCell.textContent = labTestResult[key];
        tableRow.appendChild(tableCell);
      }
      table.appendChild(tableRow);
    }
    //add a header naming given medicine
    const header = document.createElement("h3");
    header.textContent = "Completed Lab Test Results";
    doctorInfoDiv.appendChild(header);
    doctorInfoDiv.appendChild(table);
  };

  //showTakenMedicineOnaGivenAppointment
  const showTakenMedicineOnaGivenAppointment = async () => {
    if (isLoggedIn === false) {
      alert("Please login first");
    }
    console.log(doctorId);
    //take patient name from html
    const appointmentId = document.getElementById("appointmentId").value;
    const patientName = document.getElementById("patientNameOnaGivenAppointment").value;
    // Check if doctor ID is not empty
    if (doctorId != "") {
      const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ appointmentId: appointmentId, patientName: patientName, doctorId: parseInt(doctorId)}),
      };
      try {
        const url = `http://localhost:3000/viewPatientsMedicineOnaGivenAppointment/${doctorId}`;
        console.log(url);
        console.log(doctorId);
        const response = await fetch(url, options);
        console.log(response);

        // Check if the response is successful (status code 200-299)
        if (response.ok) {
          const contentType = response.headers.get("content-type");

          // Check if the response is JSON
          if (contentType && contentType.includes("application/json")) {
            const medicine = await response.json();
            console.log("Response from server:");
            console.log(medicine);
            // Display advice information
            displayMedicineOnaGivenAppointment(medicine);
          } else {
            // Handle the case when the response is not JSON
            console.error("Unexpected response format: Not JSON");
          }
        } else {
          // Handle the case when the response status is not OK
          console.error("Request failed with status:", response.status);
        }
      } catch (error) {
        console.error(error);
      }
    }
  };
  //display medicine
  //show the result in a table
  const displayMedicineOnaGivenAppointment = (medicines) => {
    if(medicines.length===0){
      //show in html that no appointments are there
      const doctorInfoDiv = document.getElementById("takenMedicineOnaGivenAppointment");
      doctorInfoDiv.innerHTML = "NO MEDICINE";
      return;
      //just show no appointments in div
      //no need to show table

    }
  
    const doctorInfoDiv = document.getElementById("takenMedicineOnaGivenAppointment");
    doctorInfoDiv.innerHTML = "";
    // Display data in a table
    const table = document.createElement("table");
    // Add table header row
    const tableHeader = document.createElement("tr");
    for (const key in medicines[0]) {
      const tableHeaderCell = document.createElement("th");
      tableHeaderCell.textContent = key;
      tableHeader.appendChild(tableHeaderCell);
    }
    table.appendChild(tableHeader);
    // Add table rows with data
    for (const medicine of medicines) {
      const tableRow = document.createElement("tr");
      for (const key in medicine) {
        const tableCell = document.createElement("td");
        tableCell.textContent = medicine[key];
        tableRow.appendChild(tableCell);
      }
      table.appendChild(tableRow);
    }
    //add a header naming given medicine
    const header = document.createElement("h3");
    header.textContent = "Given Medicine";
    doctorInfoDiv.appendChild(header);
    doctorInfoDiv.appendChild(table);
  };


  //showTakenAdviceOnaGivenAppointment
  const showTakenAdviceOnaGivenAppointment= async () => {
    if (isLoggedIn === false) {
      alert("Please login first");
    }
    console.log(doctorId);
    //take patient name from html
    const appointmentId = document.getElementById("appointmentId").value;
    const patientName = document.getElementById("patientNameOnaGivenAppointment").value;
    // Check if doctor ID is not empty
    if (doctorId != "") {
      const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ appointmentId: appointmentId, patientName: patientName, doctorId: parseInt(doctorId)}),
      };
      try {
        const url = `http://localhost:3000/viewPatientsAdviceOnaGivenAppointment/${doctorId}`;
        console.log(url);
        console.log(doctorId);
        const response = await fetch(url, options);
        console.log(response);

        // Check if the response is successful (status code 200-299)
        if (response.ok) {
          const contentType = response.headers.get("content-type");

          // Check if the response is JSON
          if (contentType && contentType.includes("application/json")) {
            const advice = await response.json();
            console.log("Response from server:");
            console.log(advice);
            // Display advice information
            displayAdviceOnaGivenAppointment(advice);
          } else {
            // Handle the case when the response is not JSON
            console.error("Unexpected response format: Not JSON");
          }
        } else {
          // Handle the case when the response status is not OK
          console.error("Request failed with status:", response.status);
        }
      } catch (error) {
        console.error(error);
      }
    }
  };
  //display advice
  //show the result in a table
  const displayAdviceOnaGivenAppointment = (advices) => {
    if(advices.length===0){
      //show in html that no appointments are there
      const doctorInfoDiv = document.getElementById("takenAdvicesOnaGivenAppointment");
      doctorInfoDiv.innerHTML = "NO ADVICE";
      return;
      //just show no appointments in div
      //no need to show table

    }
  
    const doctorInfoDiv = document.getElementById("takenAdvicesOnaGivenAppointment");
    doctorInfoDiv.innerHTML = "";
    // Display data in a table
    const table = document.createElement("table");
    // Add table header row
    const tableHeader = document.createElement("tr");
    for (const key in advices[0]) {
      const tableHeaderCell = document.createElement("th");
      tableHeaderCell.textContent = key;
      tableHeader.appendChild(tableHeaderCell);
    }
    table.appendChild(tableHeader);
    // Add table rows with data
    for (const advice of advices) {
      const tableRow = document.createElement("tr");
      for (const key in advice) {
        const tableCell = document.createElement("td");
        tableCell.textContent = advice[key];
        tableRow.appendChild(tableCell);
      }
      table.appendChild(tableRow);
    }
    //add a header naming given medicine
    const header = document.createElement("h3");
    header.textContent = "Given Advice";
    doctorInfoDiv.appendChild(header);
    doctorInfoDiv.appendChild(table);
  };


  //showTakenLabTestOnaGivenAppointment
  const showTakenLabTestOnaGivenAppointment= async () => {
    if (isLoggedIn === false) {
      alert("Please login first");
    }
    console.log(doctorId);
    //take patient name from html
    const appointmentId = document.getElementById("appointmentId").value;
    const patientName = document.getElementById("patientNameOnaGivenAppointment").value;
    // Check if doctor ID is not empty
    if (doctorId != "") {
      const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ appointmentId: appointmentId, patientName: patientName, doctorId: parseInt(doctorId)}),
      };
      try {
        const url = `http://localhost:3000/viewPatientsLabTestOnaGivenAppointment/${doctorId}`;
        console.log(url);
        console.log(doctorId);
        const response = await fetch(url, options);
        console.log(response);

        // Check if the response is successful (status code 200-299)
        if (response.ok) {
          const contentType = response.headers.get("content-type");

          // Check if the response is JSON
          if (contentType && contentType.includes("application/json")) {
            const labTest = await response.json();
            console.log("Response from server:");
            console.log(labTest);
            // Display advice information
            displayLabTestOnaGivenAppointment(labTest);
          } else {
            // Handle the case when the response is not JSON
            console.error("Unexpected response format: Not JSON");
          }
        } else {
          // Handle the case when the response status is not OK
          console.error("Request failed with status:", response.status);
        }
      } catch (error) {
        console.error(error);
      }
    }
  };
  //display lab test
  //show the result in a table
  const displayLabTestOnaGivenAppointment = (labTests) => {
    if(labTests.length===0){
      //show in html that no appointments are there
      const doctorInfoDiv = document.getElementById("takenLabTestsOnaGivenAppointment");
      doctorInfoDiv.innerHTML = "NO LAB TEST";
      return;
      //just show no appointments in div
      //no need to show table

    }
  
    const doctorInfoDiv = document.getElementById("takenLabTestsOnaGivenAppointment");
    doctorInfoDiv.innerHTML = "";
    // Display data in a table
    const table = document.createElement("table");
    // Add table header row
    const tableHeader = document.createElement("tr");
    for (const key in labTests[0]) {
      const tableHeaderCell = document.createElement("th");
      tableHeaderCell.textContent = key;
      tableHeader.appendChild(tableHeaderCell);
    }
    table.appendChild(tableHeader);
    // Add table rows with data
    for (const labTest of labTests) {
      const tableRow = document.createElement("tr");
      for (const key in labTest) {
        const tableCell = document.createElement("td");
        tableCell.textContent = labTest[key];
        tableRow.appendChild(tableCell);
      }
      table.appendChild(tableRow);
    }
    //add a header naming given medicine
    const header = document.createElement("h3");
    header.textContent = "Given Lab Test";
    doctorInfoDiv.appendChild(header);
    doctorInfoDiv.appendChild(table);
  };

  //showTakenLabTestResultOnaGivenAppointment
  const showTakenLabTestResultOnaGivenAppointment= async () => {
    if (isLoggedIn === false) {
      alert("Please login first");
    }
    console.log(doctorId);
    //take patient name from html
    const appointmentId = document.getElementById("appointmentId").value;
    const patientName = document.getElementById("patientNameOnaGivenAppointment").value;
    // Check if doctor ID is not empty
    if (doctorId != "") {
      const options = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ appointmentId: appointmentId, patientName: patientName, doctorId: parseInt(doctorId)}),
      };
      try {
        const url = `http://localhost:3000/viewPatientsLabTestResultOnaGivenAppointment/${doctorId}`;
        console.log(url);
        console.log(doctorId);
        const response = await fetch(url, options);
        console.log(response);

        // Check if the response is successful (status code 200-299)
        if (response.ok) {
          const contentType = response.headers.get("content-type");

          // Check if the response is JSON
          if (contentType && contentType.includes("application/json")) {
            const labTestResult = await response.json();
            console.log("Response from server:");
            console.log(labTestResult);
            // Display advice information
            displayLabTestResultOnaGivenAppointment(labTestResult);
          } else {
            // Handle the case when the response is not JSON
            console.error("Unexpected response format: Not JSON");
          }
        } else {
          // Handle the case when the response status is not OK
          console.error("Request failed with status:", response.status);
        }
      } catch (error) {
        console.error(error);
      }
    }
  };
  //display lab test result
  //show the result in a table
  const displayLabTestResultOnaGivenAppointment = (labTestResults) => {
    if(labTestResults.length===0){
      //show in html that no appointments are there
      const doctorInfoDiv = document.getElementById("resultofCompletedLabTestsOnaGivenAppointment");
      doctorInfoDiv.innerHTML = "NO LAB TEST RESULT";
      return;
      //just show no appointments in div
      //no need to show table

    }
  
    const doctorInfoDiv = document.getElementById("resultofCompletedLabTestsOnaGivenAppointment");
    doctorInfoDiv.innerHTML = "";
    // Display data in a table
    const table = document.createElement("table");
    // Add table header row
    const tableHeader = document.createElement("tr");
    for (const key in labTestResults[0]) {
      const tableHeaderCell = document.createElement("th");
      tableHeaderCell.textContent = key;
      tableHeader.appendChild(tableHeaderCell);
    }
    table.appendChild(tableHeader);
    // Add table rows with data
    for (const labTestResult of labTestResults) {
      const tableRow = document.createElement("tr");
      for (const key in labTestResult) {
        const tableCell = document.createElement("td");
        tableCell.textContent = labTestResult[key];
        tableRow.appendChild(tableCell);
      }
      table.appendChild(tableRow);
    }
    //add a header naming given medicine
    const header = document.createElement("h3");
    header.textContent = "Completed Lab Test Results";
    doctorInfoDiv.appendChild(header);
    doctorInfoDiv.appendChild(table);
  };

  window.onload=login;
  