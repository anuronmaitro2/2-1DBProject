//send add a medicine request
const addNewMedicine=async()=>{
   //get data from the form
    const medicineName=document.getElementById('medicineName').value;
    const genericName=document.getElementById('genericName').value;
    const dosage=document.getElementById('dosage').value;
    const manufacturer=document.getElementById('manufacturer').value;
    const sideEffects=document.getElementById('sideEffects').value;
    const medicineData = {
      medicineName: medicineName,
      genericName: genericName,
      dosage: dosage,
      manufacturer: manufacturer,
      sideEffects: sideEffects,
    };

    const options = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(medicineData),
    };

    try {
      const url = 'http://localhost:3000/addMedicine';
      const response = await fetch(url, options);
      if (response.ok) {

          const medicine = await response.json();
          console.log(medicine);
         //show in front end that medicine is added
            //add a header and show that medicine is added
            //create a header
            const div = document.getElementById('addMedicineMessage');
            div.innerHTML = '<h1>Medicine is added</h1>';
            div.style.color = 'green';
            div.style.textAlign = 'center';
            //append the header to the body
            //get the div by id
            //const div=document.getElementById('addMedicine');
            //div.appendChild(header);
          // Display patient details on the prescription page
         
      } else {
        console.error("Request failed with status:", response.status);
      }
    } catch (error) {
      console.error(error);
    }

    
  }
  const addNewLabTest=async()=>{
    //get data from the form
   const testName=document.getElementById('testName').value;
   const description=document.getElementById('description').value;
    const labTestData = {
        testName: testName,
        description: description,
    };

    const options = {
        method: "POST",
        headers: {
        "Content-Type": "application/json",
        },
        body: JSON.stringify(labTestData),
    };

    try {
        const url = "http://localhost:3000/addLabTest";
        const response = await fetch(url, options);

        if (response.ok) {
        const contentType = response.headers.get("content-type");
        alert("Lab test added successfully");
        } else {
        console.error("Request failed with status:", response.status);
        }
    } catch (error) {
        console.error(error);
    }
};